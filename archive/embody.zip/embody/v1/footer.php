

</div>
<div style="font-size:9px;margin-left:auto;margin-right:auto;width:400px;">If you experience any error or malfunction, please contact <b style="font-size:9px;color:#999"><?php echo($pagetexts['contact_email']);?></b>.</div>
</body>
</html>
