#!/bin/bash
echo "tar cvf $1/admin/data.tar $1/subjects/"
tar cvf $1/admin/data/data.tar $1/subjects/
