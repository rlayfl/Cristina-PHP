<?php
include('header.php');
?>

<form id="intro" method="POST" action="admin.php">
<h1>Admin log-in</h1>
    <br><br>
    <input style="font-size:14px;" name="key" type="text" onclick="this.value=''" value="enter admin key"> 
</form>


<?php
include('footer.php');
?>
