<?php 
?>
<html>
<head>
<title>Admin page</title>
<LINK href="../css/main.css" rel="stylesheet" type="text/css">
</head>
<body>
<div id="container">

